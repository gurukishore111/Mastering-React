import React from 'react';
//import logo from './logo.svg';
import './App.css';
import Navbar from "./components/navbar"
import Counters from "./components/counters"
import Counter from './components/counter';


class App extends React.Component {
  state = { 
    //Counter have its unqiue state 
     counters:[
         {id:1,value:0},
         {id:2,value:0},
         {id:3,value:0},
         {id:4,value:0}
     ]
 };

constructor(){
  super(); 
   console.log('App ->constructor')
}

componentDidMount(){
  console.log('App ->Mounted')
}


 handleDelete =(counterId)=>{
    // console.log("Event Called!",counterId)
    const counters = this.state.counters.filter(c =>c.id !== counterId)
    this.setState({counters})
 }
 handleIncreament = counter =>{
     const counters = [...this.state.counters]
     const index = counters.indexOf(counter);
     counters[index] = {...counter};
     counters[index].value++;
     this.setState({counters})
 }
 handleDecreament = counter =>{
  const counters = [...this.state.counters]
  const index = counters.indexOf(counter);
  counters[index] = {...counter};
  counters[index].value--;
  this.setState({counters})
 }
  handleReset =()=>{
        const counters= this.state.counters.map(m =>{ m.value =0
        return m
    });
    this.setState({ counters})
 } 
 render() {
   console.log('App ->rendered')
  return (
    <div>
      <Navbar totalCounters={this.state.counters.filter(c =>c.value > 0).length} />
    <main className="container" >
      <Counters 
      counters ={this.state.counters}
      onReset={this.handleReset}
      onIncreament ={this.handleIncreament}
      onDelete ={this.handleDelete}
      onDecreament ={this.handleDecreament} />
    </main>
    </div>
  );
}
}
export default App;
