import React, { Component } from 'react';

class Counter extends Component {
    render() { 
    console.log("Counter ->rendered")
        return ( 
            <div className ="row">
                <div className="col-1">
             <span style={{fontWeight:"bolder",fontSize:19}} className={this.getBadge()}>{this.formatCount()}</span>
                </div>
                <div className="col">
                <button  onClick={()=>this.props.onIncreament(this.props.counter)}className="btn btn-secondary m-0 ">+</button>
            <button  onClick={()=>this.props.onDecreament(this.props.counter)}className="btn btn-secondary m-2 " disabled={this.props.counter.value=== 0? "disabled": ""}>-</button>
             <button onClick={()=>this.props.onDelete(this.props.counter.id)}  className="btn btn-sm btn-danger m-2">x</button>
                </div>
            </div>
         );
    }
    getBadge() {
        let classes = 'badge m-2 ';
        classes += this.props.counter.value === 0 ? 'badge-warning' : 'badge-primary';
        return classes;
    }

    formatCount(){
        //destruturing
        const {value} = this.props.counter;
        return value === 0? "Zero" : value;
    }
}
 
export default Counter;