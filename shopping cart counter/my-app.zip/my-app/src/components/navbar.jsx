import React, { Component } from 'react';


//Statless Functional Components
const Navbar = (props) => {
    console.log("Navbar ->rendered")
    return ( 
            <div>
                <nav className="navbar navbar-light bg-light">
                    <a className="navbar-brand" style={{fontWeight:"bolder"}} >
                      NavBar <span className="badge badge-pill badge-secondary">{props.totalCounters}</span>
                        </a>
                </nav>
            </div>
     );
}
 
export default Navbar;